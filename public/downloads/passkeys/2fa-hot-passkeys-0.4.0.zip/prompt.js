(() => {
  // src/encoding.js
  function encode(value) {
    const bytes = new Uint8Array(value);
    let text = "";
    for (let i = 0; i < bytes.length; i += 8192)
      text += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return btoa(text).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function decode(value, max = 1e6) {
    if (typeof value !== "string" || value.length > max * 2 || !/^[A-Za-z0-9_-]*$/.test(value))
      throw new Error("\u51ED\u636E\u7F16\u7801\u4E0D\u6B63\u786E\u3002");
    const bytes = Uint8Array.from(
      atob(value.replace(/-/g, "+").replace(/_/g, "/")),
      (c) => c.charCodeAt(0)
    );
    if (bytes.length > max || encode(bytes) !== value) throw new Error("\u51ED\u636E\u7F16\u7801\u4E0D\u6B63\u786E\u3002");
    return bytes;
  }
  var random = (size) => crypto.getRandomValues(new Uint8Array(size));

  // src/device.js
  var deviceSupported = () => typeof PublicKeyCredential === "function" && !!navigator.credentials?.get;
  async function deviceSecret(device) {
    const credential = await navigator.credentials.get({
      publicKey: {
        challenge: random(32),
        userVerification: "required",
        allowCredentials: [{ type: "public-key", id: decode(device.credentialId, 1024) }],
        extensions: { prf: { eval: { first: decode(device.salt, 32) } } }
      }
    });
    const first = credential.getClientExtensionResults().prf?.results?.first;
    if (!first) throw new Error("\u8FD9\u53F0\u8BBE\u5907\u7684\u9A8C\u8BC1\u5668\u6CA1\u6709\u8FD4\u56DE\u89E3\u9501\u6240\u9700\u7684\u6570\u636E\uFF0C\u8BF7\u6539\u7528\u4E3B\u53E3\u4EE4\u3002");
    return encode(first);
  }

  // src/prompt.js
  var $ = (id) => document.getElementById(id);
  var token = new URLSearchParams(location.search).get("request");
  var framed = window.top !== window;
  var state;
  var busy = false;
  var finished = false;
  var clear = /* @__PURE__ */ new Map();
  var reachable = (button) => !framed || clear.get(button.parentElement) === true;
  async function send(action, values = {}) {
    const result = await chrome.runtime.sendMessage({ action, token, ...values });
    if (!result.ok) {
      const error = new Error(result.error);
      error.code = result.code;
      throw error;
    }
    return result;
  }
  function feedback(id, text = "") {
    $(id).textContent = text;
    $(id).hidden = !text;
  }
  function guard() {
    for (const id of ["approve", "exists"]) $(id).disabled = busy || !reachable($(id));
  }
  async function run(action) {
    if (busy || finished) return;
    busy = true;
    feedback("error");
    const buttons = [...document.querySelectorAll("button")];
    buttons.forEach((b) => b.disabled = true);
    try {
      await action();
    } catch (e) {
      if (e.code === "Locked") showGate();
      feedback("error", e.message || "\u65E0\u6CD5\u5B8C\u6210\u64CD\u4F5C\u3002");
    } finally {
      busy = false;
      buttons.forEach((b) => b.disabled = false);
      guard();
    }
  }
  function done(text) {
    finished = true;
    for (const id of ["gate", "approval", "duplicate", "request-actions"]) $(id).hidden = true;
    feedback("notice", text);
    if (!framed) setTimeout(() => window.close(), 900);
  }
  function watchVisibility() {
    if (!framed) return;
    if (!("isVisible" in IntersectionObserverEntry.prototype)) {
      $("covered").hidden = false;
      guard();
      return;
    }
    const timers = /* @__PURE__ */ new Map(), covered = /* @__PURE__ */ new Map();
    const observer = new IntersectionObserver(
      (entries) => {
        for (const { target, isVisible, isIntersecting } of entries) {
          clearTimeout(timers.get(target));
          covered.set(target, isIntersecting && !isVisible);
          if (isVisible)
            timers.set(
              target,
              setTimeout(() => {
                clear.set(target, true);
                guard();
              }, 400)
            );
          else clear.set(target, false);
        }
        $("covered").hidden = ![...covered.values()].some(Boolean);
        guard();
      },
      { trackVisibility: true, delay: 100, threshold: [1] }
    );
    observer.observe($("approve-slot"));
    observer.observe($("exists-slot"));
  }
  function showGate() {
    for (const id of ["approval", "duplicate", "missing"]) $(id).hidden = true;
    $("gate").hidden = false;
    $("device").hidden = !state.device || !deviceSupported();
    (state.device && deviceSupported() ? $("device") : $("password")).focus();
  }
  async function proceed() {
    $("gate").hidden = true;
    const result = await send("list");
    const create = state.request.kind === "create";
    if (create && result.excluded) {
      $("duplicate").hidden = false;
      $("exists").focus();
      return;
    }
    $("approval").hidden = false;
    $("approval-title").textContent = create ? "\u786E\u8BA4\u4FDD\u5B58" : "\u9009\u62E9\u767B\u5F55\u8D26\u53F7";
    $("approve").textContent = create ? "\u521B\u5EFA\u5E76\u4FDD\u5B58" : "\u786E\u8BA4\u767B\u5F55";
    $("choices").replaceChildren();
    if (create) {
      const p = document.createElement("p");
      p.textContent = `${state.request.rpId} \xB7 ${state.request.userName}`;
      $("choices").append(p);
    } else
      for (const [index, r] of result.records.entries()) {
        const label = document.createElement("label");
        label.className = "choice check";
        const input = document.createElement("input");
        input.type = "radio";
        input.name = "credential";
        input.value = r.credentialId;
        input.checked = index === 0;
        const text = document.createElement("span");
        text.textContent = r.label ? `${r.label} \xB7 ${r.userName || r.userDisplayName}` : r.userName || r.userDisplayName;
        label.append(input, text);
        $("choices").append(label);
      }
    if (!create && !result.records.length) {
      $("approval").hidden = true;
      feedback("notice", "\u8FD9\u91CC\u6CA1\u6709\u6B64\u7F51\u7AD9\u53EF\u7528\u7684\u901A\u884C\u5BC6\u94A5\uFF0C\u8BF7\u4F7F\u7528\u7CFB\u7EDF\u6216\u5176\u4ED6\u9A8C\u8BC1\u5668\u3002");
      $("fallback").focus();
      return;
    }
    $("approve").focus();
  }
  async function start() {
    if (!token) return;
    if (framed) document.documentElement.classList.add("framed");
    document.body.hidden = false;
    state = await send("status");
    const request = state.request;
    $("title").textContent = request.kind === "create" ? "\u4FDD\u5B58\u65B0\u7684\u901A\u884C\u5BC6\u94A5" : "\u4F7F\u7528\u901A\u884C\u5BC6\u94A5\u767B\u5F55";
    $("origin").textContent = request.origin;
    if (request.topOrigin && request.topOrigin !== request.origin) {
      $("embedded").hidden = false;
      $("embedded").textContent = `\u5D4C\u5728 ${request.topOrigin} \u7684\u9875\u9762\u4E2D`;
    }
    $("account").textContent = request.userName ? `\u8D26\u53F7\uFF1A${request.userName}` : `\u51ED\u636E\u57DF\u540D\uFF1A${request.rpId}`;
    watchVisibility();
    if (!state.exists) {
      $("missing").hidden = false;
      $("fallback").focus();
      return;
    }
    if (state.unlocked) await proceed();
    else showGate();
  }
  $("unlock-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      await send("unlock", { password: $("password").value });
      $("password").value = "";
      await proceed();
    });
  });
  $("device").addEventListener(
    "click",
    () => run(async () => {
      const secret = await deviceSecret(state.device).catch((e) => {
        throw new Error(e?.name === "NotAllowedError" ? "\u8BBE\u5907\u9A8C\u8BC1\u5DF2\u53D6\u6D88\uFF0C\u53EF\u6539\u7528\u4E3B\u53E3\u4EE4\u3002" : e.message);
      });
      await send("device-unlock", { credentialId: state.device.credentialId, secret });
      await proceed();
    })
  );
  $("approve-form").addEventListener("submit", (event) => {
    event.preventDefault();
    if (!reachable($("approve"))) return;
    run(async () => {
      const result = await send("approve", {
        credentialId: document.querySelector("input[name=credential]:checked")?.value
      });
      done(result.kind === "create" ? "\u5DF2\u4FDD\u5B58\uFF0C\u6B63\u5728\u8FD4\u56DE\u7F51\u7AD9\u3002" : "\u5DF2\u5B8C\u6210\u9A8C\u8BC1\uFF0C\u6B63\u5728\u8FD4\u56DE\u7F51\u7AD9\u3002");
    });
  });
  $("exists").addEventListener("click", () => {
    if (!reachable($("exists"))) return;
    run(async () => {
      await send("exists");
      done("\u5DF2\u544A\u77E5\u7F51\u7AD9\u6B64\u8D26\u53F7\u5DF2\u6709\u901A\u884C\u5BC6\u94A5\u3002");
    });
  });
  for (const action of ["fallback", "deny"])
    $(action).addEventListener(
      "click",
      () => run(async () => {
        await send(action);
        done(action === "fallback" ? "\u5DF2\u4EA4\u7ED9\u7CFB\u7EDF\u6216\u5176\u4ED6\u9A8C\u8BC1\u5668\u3002" : "\u5DF2\u53D6\u6D88\u3002");
      })
    );
  $("close").addEventListener("click", () => $("deny").click());
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") $("deny").click();
  });
  run(start);
})();
