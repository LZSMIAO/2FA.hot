(() => {
  // src/content.js
  (() => {
    const namespace = "2fa.hot/passkeys/v1", active = /* @__PURE__ */ new Map(), offers = /* @__PURE__ */ new Map();
    const reply = (id, value) => window.postMessage({ namespace, direction: "response", id, ...value }, location.origin);
    const send = (message) => chrome.runtime.sendMessage(message);
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const withdraw = (token) => send({ action: "cancel", token }).catch(() => {
    });
    const permitted = (kind) => window.isSecureContext && document.featurePolicy?.allowsFeature(`publickey-credentials-${kind}`) !== false;
    function mount(token) {
      const host = document.createElement("div");
      host.setAttribute("popover", "manual");
      host.style.cssText = "all:initial;display:block;position:fixed;inset:16px 16px auto auto;width:min(400px,calc(100vw - 32px));height:min(560px,calc(100vh - 32px));margin:0;padding:0;border:0;background:transparent;overflow:visible;z-index:2147483647";
      const root = host.attachShadow({ mode: "closed" });
      const frame = document.createElement("iframe");
      frame.src = chrome.runtime.getURL(`prompt.html?request=${encodeURIComponent(token)}`);
      frame.allow = "publickey-credentials-get *";
      frame.title = "2fa.hot \u901A\u884C\u5BC6\u94A5";
      frame.setAttribute(
        "style",
        "display:block;width:100%;height:100%;border:0;border-radius:12px;box-shadow:0 18px 48px rgba(0,0,0,.35);background:transparent;color-scheme:normal"
      );
      root.append(frame);
      document.documentElement.append(host);
      try {
        host.showPopover();
      } catch {
      }
      frame.addEventListener("load", () => frame.focus(), { once: true });
      return host;
    }
    async function perform(id, kind, options) {
      if (active.size) return { fallback: true };
      active.set(id, null);
      let overlay;
      try {
        const started = await send({ action: "begin", kind, options });
        if (!active.has(id)) {
          if (started.token) withdraw(started.token);
          return null;
        }
        if (!started.token) return { fallback: true };
        active.set(id, started.token);
        if (started.mode === "page") overlay = mount(started.token);
        while (active.has(id)) {
          await sleep(400);
          const status = await send({ action: "poll", token: started.token });
          if (status.done) return status.result;
        }
        return null;
      } catch {
        return { fallback: true };
      } finally {
        active.delete(id);
        overlay?.remove();
      }
    }
    window.addEventListener("message", async (event) => {
      const data = event.data;
      if (event.source !== window || event.origin !== location.origin || data?.namespace !== namespace || typeof data.id !== "string")
        return;
      if (data.direction === "cancel") {
        const token = active.get(data.id);
        active.delete(data.id);
        if (token) withdraw(token);
        if (offers.delete(data.id)) refreshOffer();
        return;
      }
      if (data.direction === "conditional") {
        if (!permitted("get")) return;
        try {
          const probe = await send({ action: "probe", options: data.options });
          if (!probe?.match) return;
        } catch {
          return;
        }
        offers.set(data.id, data.options);
        refreshOffer();
        return;
      }
      if (data.direction !== "request") return;
      if (!["create", "get"].includes(data.kind) || !permitted(data.kind)) {
        reply(data.id, { fallback: true });
        return;
      }
      const result = await perform(data.id, data.kind, data.options);
      if (result) reply(data.id, result);
    });
    window.addEventListener("pagehide", () => {
      for (const token of active.values()) if (token) withdraw(token);
      active.clear();
      offers.clear();
    });
    let offer = null, field = null;
    const eligible = (element) => element instanceof HTMLInputElement && (element.autocomplete || element.getAttribute("autocomplete") || "").toLowerCase().split(/\s+/).includes("webauthn");
    function buildOffer() {
      const host = document.createElement("div");
      host.setAttribute("popover", "manual");
      host.style.cssText = "all:initial;display:block;position:fixed;margin:0;padding:0;border:0;background:transparent;overflow:visible;z-index:2147483647";
      const root = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      style.textContent = 'button{all:initial;box-sizing:border-box;display:flex;align-items:center;gap:8px;min-height:40px;padding:8px 12px;border-radius:8px;cursor:pointer;font:500 14px/1.3 system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#f4f4f5;background:#18181b;box-shadow:0 8px 24px rgba(0,0,0,.28);border:1px solid #3f3f46}button:hover,button:focus-visible{background:#27272a;outline:2px solid #4ade80;outline-offset:1px}span{font-weight:700;color:#4ade80}';
      const button = document.createElement("button");
      button.type = "button";
      const mark = document.createElement("span");
      mark.textContent = "2fa.hot";
      button.append(mark, "\u4F7F\u7528\u4FDD\u5B58\u5728\u8FD9\u91CC\u7684\u901A\u884C\u5BC6\u94A5\u767B\u5F55");
      button.addEventListener("pointerdown", (event) => event.preventDefault());
      button.addEventListener("click", (event) => {
        if (!event.isTrusted) return;
        signIn();
      });
      root.append(style, button);
      return host;
    }
    function place() {
      if (!offer || !field) return;
      const box = field.getBoundingClientRect();
      offer.style.left = `${Math.max(8, box.left)}px`;
      offer.style.top = `${Math.min(window.innerHeight - 48, box.bottom + 6)}px`;
    }
    function hideOffer() {
      offer?.remove();
      field = null;
    }
    function showOffer(target) {
      if (!offers.size || active.size) return hideOffer();
      offer ??= buildOffer();
      field = target;
      if (!offer.isConnected) {
        document.documentElement.append(offer);
        try {
          offer.showPopover();
        } catch {
        }
      }
      place();
    }
    function refreshOffer() {
      const focused = document.activeElement;
      if (offers.size && eligible(focused)) showOffer(focused);
      else hideOffer();
    }
    async function signIn() {
      const entry = [...offers].at(-1);
      if (!entry) return hideOffer();
      const [id, options] = entry;
      hideOffer();
      const result = await perform(id, "get", options);
      if (result?.value && offers.delete(id)) reply(id, result);
    }
    document.addEventListener(
      "focusin",
      (event) => offers.size && eligible(event.target) ? showOffer(event.target) : hideOffer(),
      true
    );
    document.addEventListener(
      "focusout",
      () => setTimeout(() => eligible(document.activeElement) || hideOffer(), 150),
      true
    );
    document.addEventListener("keydown", (event) => event.key === "Escape" && hideOffer(), true);
    window.addEventListener("scroll", place, { capture: true, passive: true });
    window.addEventListener("resize", place, { passive: true });
  })();
})();
