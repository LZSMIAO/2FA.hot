(() => {
  // src/encoding.js
  function encode(value) {
    const bytes = new Uint8Array(value);
    let text = "";
    for (let i = 0; i < bytes.length; i += 8192)
      text += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return btoa(text).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function decode(value, max = 1e6) {
    if (typeof value !== "string" || value.length > max * 2 || !/^[A-Za-z0-9_-]*$/.test(value))
      throw new Error("\u51ED\u636E\u7F16\u7801\u4E0D\u6B63\u786E\u3002");
    const bytes = Uint8Array.from(
      atob(value.replace(/-/g, "+").replace(/_/g, "/")),
      (c) => c.charCodeAt(0)
    );
    if (bytes.length > max || encode(bytes) !== value) throw new Error("\u51ED\u636E\u7F16\u7801\u4E0D\u6B63\u786E\u3002");
    return bytes;
  }
  var random = (size) => crypto.getRandomValues(new Uint8Array(size));

  // src/device.js
  var deviceSupported = () => typeof PublicKeyCredential === "function" && !!navigator.credentials?.get;
  async function deviceSecret(device) {
    const credential = await navigator.credentials.get({
      publicKey: {
        challenge: random(32),
        userVerification: "required",
        allowCredentials: [{ type: "public-key", id: decode(device.credentialId, 1024) }],
        extensions: { prf: { eval: { first: decode(device.salt, 32) } } }
      }
    });
    const first = credential.getClientExtensionResults().prf?.results?.first;
    if (!first) throw new Error("\u8FD9\u53F0\u8BBE\u5907\u7684\u9A8C\u8BC1\u5668\u6CA1\u6709\u8FD4\u56DE\u89E3\u9501\u6240\u9700\u7684\u6570\u636E\uFF0C\u8BF7\u6539\u7528\u4E3B\u53E3\u4EE4\u3002");
    return encode(first);
  }
  async function enrollDevice() {
    const salt = random(32);
    const credential = await navigator.credentials.create({
      publicKey: {
        rp: { name: "2fa.hot Passkeys" },
        user: { id: random(16), name: "2fa.hot \u901A\u884C\u5BC6\u94A5\u5E93", displayName: "2fa.hot \u901A\u884C\u5BC6\u94A5\u5E93" },
        challenge: random(32),
        pubKeyCredParams: [
          { type: "public-key", alg: -7 },
          { type: "public-key", alg: -257 }
        ],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required",
          residentKey: "discouraged"
        },
        extensions: { prf: { eval: { first: salt } } }
      }
    });
    const prf = credential.getClientExtensionResults().prf;
    if (!prf?.enabled)
      throw new Error("\u8FD9\u53F0\u8BBE\u5907\u7684 Touch ID\u3001Windows Hello \u6216\u7CFB\u7EDF\u9A8C\u8BC1\u5668\u4E0D\u652F\u6301\u7528\u6765\u89E3\u9501\u7684 PRF \u529F\u80FD\u3002");
    const device = { credentialId: encode(credential.rawId), salt: encode(salt) };
    const secret = prf.results?.first ? encode(prf.results.first) : await deviceSecret(device);
    return { ...device, secret };
  }

  // src/ui.js
  var $ = (id) => document.getElementById(id);
  var companion = new URLSearchParams(location.search).get("companion");
  var state;
  var records = [];
  var importedText = "";
  var importPassword = "";
  var selected = /* @__PURE__ */ new Set();
  var renaming = null;
  var busy = false;
  async function send(action, values = {}) {
    const result = await chrome.runtime.sendMessage({ action, companion, ...values });
    if (!result.ok) {
      const error = new Error(result.error);
      error.code = result.code;
      throw error;
    }
    return result;
  }
  function feedback(id, text = "") {
    $(id).textContent = text;
    $(id).hidden = !text;
  }
  async function run(action) {
    if (busy) return;
    busy = true;
    feedback("error");
    feedback("notice");
    const buttons = [...document.querySelectorAll("button")];
    buttons.forEach((b) => b.disabled = true);
    try {
      await action();
    } catch (e) {
      if (e.code === "Locked") showGate();
      feedback("error", e.message || "\u65E0\u6CD5\u5B8C\u6210\u64CD\u4F5C\u3002");
    } finally {
      busy = false;
      buttons.forEach((b) => b.disabled = false);
    }
  }
  function identity(r) {
    return `${r.rpId}:${r.credentialId}`;
  }
  function visibleRecords() {
    const query = $("search").value.toLowerCase();
    return records.filter(
      (r) => `${r.rpId} ${r.userName} ${r.userDisplayName} ${r.label ?? ""}`.toLowerCase().includes(query)
    );
  }
  function selection() {
    $("selected-count").textContent = `\u5DF2\u9009 ${selected.size} \u6761`;
    const visible = visibleRecords();
    $("select-all").checked = !!visible.length && visible.every((r) => selected.has(identity(r)));
    $("select-all").indeterminate = visible.some((r) => selected.has(identity(r))) && !$("select-all").checked;
  }
  function renameField(r) {
    const form = document.createElement("form");
    form.className = "rename";
    const input = document.createElement("input");
    input.value = r.label ?? "";
    input.maxLength = 256;
    input.placeholder = r.rpId;
    input.setAttribute("aria-label", `${r.rpId} \u7684\u540D\u79F0`);
    const save = document.createElement("button");
    save.className = "secondary";
    save.textContent = "\u4FDD\u5B58";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "text-button";
    cancel.textContent = "\u53D6\u6D88";
    cancel.addEventListener("click", () => {
      renaming = null;
      render();
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      run(async () => {
        records = (await send("rename", { id: identity(r), label: input.value })).records;
        renaming = null;
        render();
        feedback("notice", input.value.trim() ? "\u5DF2\u66F4\u65B0\u540D\u79F0\u3002" : "\u5DF2\u6062\u590D\u4E3A\u7F51\u7AD9\u57DF\u540D\u3002");
      });
    });
    form.append(input, save, cancel);
    setTimeout(() => input.focus());
    return form;
  }
  function render() {
    $("records").replaceChildren();
    const visible = visibleRecords();
    $("count").textContent = `${records.length} \u6761\u901A\u884C\u5BC6\u94A5`;
    $("empty").hidden = records.length > 0;
    for (const r of visible) {
      const row = document.createElement("div");
      row.className = "record";
      const box = document.createElement("input");
      box.type = "checkbox";
      box.checked = selected.has(identity(r));
      box.setAttribute("aria-label", `\u9009\u62E9 ${r.label || r.rpId} ${r.userName}`);
      box.addEventListener("change", () => {
        box.checked ? selected.add(identity(r)) : selected.delete(identity(r));
        selection();
      });
      const info = document.createElement("div");
      info.className = "record-info";
      const site = document.createElement("strong");
      site.textContent = r.label || r.rpId;
      const user = document.createElement("span");
      user.textContent = [r.label ? r.rpId : "", r.userName || r.userDisplayName || "\u672A\u547D\u540D\u8D26\u53F7"].filter(Boolean).join(" \xB7 ");
      info.append(site, user);
      const time = document.createElement("time");
      time.textContent = r.lastUsedAt ? `\u6700\u8FD1\u4F7F\u7528 ${new Date(r.lastUsedAt).toLocaleDateString()}` : "\u5C1A\u672A\u4F7F\u7528";
      const rename = document.createElement("button");
      rename.type = "button";
      rename.className = "text-button";
      rename.textContent = "\u91CD\u547D\u540D";
      rename.setAttribute("aria-label", `\u91CD\u547D\u540D ${r.label || r.rpId}`);
      rename.addEventListener("click", () => {
        renaming = identity(r);
        render();
      });
      row.append(box, info, time);
      if (!companion) row.append(rename);
      $("records").append(row);
      if (renaming === identity(r)) $("records").append(renameField(r));
    }
    if (!visible.length && records.length) {
      const p = document.createElement("p");
      p.textContent = "\u6CA1\u6709\u5339\u914D\u7684\u7F51\u7AD9\u6216\u8D26\u53F7\u3002";
      $("records").append(p);
    }
    selection();
  }
  async function refresh() {
    records = (await send("list")).records;
    selected = new Set([...selected].filter((id) => records.some((r) => identity(r) === id)));
    render();
  }
  function forgetView() {
    importedText = "";
    importPassword = "";
    records = [];
    selected.clear();
  }
  async function finishCompanion() {
    if (!companion) return;
    await send("companion-finish");
    forgetView();
    window.close();
  }
  function showCompanion() {
    const { operation, label } = state.companion;
    $("manager").hidden = ["list", "rename"].includes(operation);
    $("share-list").hidden = operation !== "list";
    if (operation === "list") {
      $("share-summary").textContent = `\u5171 ${records.length} \u6761\u901A\u884C\u5BC6\u94A5\u3002\u786E\u8BA4\u540E\u5728\u8BF7\u6C42\u9875\u9762\u663E\u793A\u7F51\u7AD9\u3001\u8D26\u53F7\u3001\u540D\u79F0\u548C\u4F7F\u7528\u65F6\u95F4\u3002`;
      $("share-confirm").focus();
      return;
    }
    if (operation === "rename") {
      const target = records.find((r) => identity(r) === state.companion.ids[0]);
      if (!target) throw new Error("\u627E\u4E0D\u5230\u8FD9\u628A\u901A\u884C\u5BC6\u94A5\u3002");
      $("rename-request").hidden = false;
      $("rename-summary").textContent = label?.trim() ? `${target.label || target.rpId} \xB7 ${target.userName} \u2192 \u201C${label.trim()}\u201D` : `${target.label || target.rpId} \xB7 ${target.userName} \u2192 \u6062\u590D\u4E3A\u7F51\u7AD9\u57DF\u540D`;
      $("rename-confirm").focus();
      return;
    }
    selected = new Set(state.companion.ids);
    if (operation !== "import") records = records.filter((r) => selected.has(identity(r)));
    render();
    document.querySelector(".toolbar").hidden = true;
    document.querySelector(".list-heading").hidden = true;
    document.querySelector(".selection-bar").hidden = operation !== "remove";
    $("settings-section").hidden = true;
    $("records").hidden = operation === "import";
    $("empty").hidden = true;
    for (const name of ["import", "export"]) {
      $(name + "-section").hidden = operation !== name;
      $(name + "-section").open = operation === name;
    }
    for (const box of document.querySelectorAll("#records input")) box.disabled = true;
    if (operation === "remove") $("remove").focus();
  }
  function showGate() {
    $("manager").hidden = true;
    $("gate").hidden = false;
    const device = state.exists && state.device && deviceSupported();
    $("device-unlock").hidden = !device;
    (device ? $("device-unlock") : $("password")).focus();
  }
  function showSettings() {
    $("lock-after").value = String(state.settings.lockAfter);
    $("prompt-mode").value = state.settings.prompt;
    $("paused").checked = state.paused;
    const enabled = !!state.device;
    $("device-state").textContent = !deviceSupported() ? "\u5F53\u524D\u6D4F\u89C8\u5668\u65E0\u6CD5\u8C03\u7528\u7CFB\u7EDF\u9A8C\u8BC1\u5668\u3002" : enabled ? "\u5DF2\u542F\u7528\uFF1A\u53EF\u7528\u8FD9\u53F0\u8BBE\u5907\u7684 Touch ID\u3001Windows Hello \u6216\u7CFB\u7EDF PIN \u89E3\u9501\u3002\u66F4\u6362\u4E3B\u53E3\u4EE4\u540E\u4ECD\u7136\u6709\u6548\u3002" : "\u542F\u7528\u540E\uFF0C\u53EF\u7528\u8FD9\u53F0\u8BBE\u5907\u7684 Touch ID\u3001Windows Hello \u6216\u7CFB\u7EDF PIN \u4EE3\u66FF\u4E3B\u53E3\u4EE4\u89E3\u9501\u3002\u9700\u8981\u8BBE\u5907\u9A8C\u8BC1\u5668\u652F\u6301 PRF\u3002";
    $("device-toggle").textContent = enabled ? "\u505C\u7528\u8BBE\u5907\u89E3\u9501" : "\u542F\u7528 Touch ID / Windows Hello \u89E3\u9501";
    $("device-toggle").disabled = !deviceSupported();
    $("device-password-field").hidden = enabled;
  }
  async function opened() {
    $("gate").hidden = true;
    $("password").value = "";
    $("confirmation").value = "";
    $("manager").hidden = false;
    records = (await send("list")).records;
    render();
    showSettings();
    if (companion) showCompanion();
    else $("search").focus();
  }
  $("share-confirm").addEventListener("click", () => run(finishCompanion));
  $("rename-confirm").addEventListener(
    "click",
    () => run(async () => {
      await send("rename");
      await finishCompanion();
    })
  );
  $("companion-cancel").addEventListener("click", () => window.close());
  async function start() {
    state = await send("status");
    if (!state.exists) {
      $("gate-title").textContent = "\u521B\u5EFA\u672C\u5730\u5BC6\u94A5\u5E93";
      $("unlock").textContent = "\u521B\u5EFA\u5BC6\u94A5\u5E93";
      $("confirmation-field").hidden = false;
      $("setup-hint").hidden = false;
      $("password").minLength = 12;
      $("password").autocomplete = "new-password";
      $("confirmation").required = true;
    }
    if (companion) {
      const names = {
        list: "\u5728\u7F51\u7AD9\u4E2D\u67E5\u770B\u901A\u884C\u5BC6\u94A5",
        import: "\u5BFC\u5165\u901A\u884C\u5BC6\u94A5",
        export: "\u5BFC\u51FA\u6240\u9009\u901A\u884C\u5BC6\u94A5",
        remove: "\u5220\u9664\u6240\u9009\u901A\u884C\u5BC6\u94A5",
        rename: "\u91CD\u547D\u540D\u901A\u884C\u5BC6\u94A5"
      };
      $("title").textContent = names[state.companion.operation];
      $("subtitle").textContent = "\u6838\u5BF9\u8BF7\u6C42\u6765\u6E90\uFF0C\u5728\u6B64\u7A97\u53E3\u89E3\u9501\u5E76\u786E\u8BA4\uFF0C\u5B8C\u6210\u540E\u81EA\u52A8\u8FD4\u56DE\u539F\u9875\u9762\u3002";
      $("companion-info").hidden = false;
      $("companion-origin").textContent = state.companion.origin;
      $("companion-cancel").hidden = false;
    }
    if (state.unlocked) await opened();
    else showGate();
  }
  $("unlock-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      const entered = $("password").value;
      if (!state.exists) {
        if (entered !== $("confirmation").value) throw new Error("\u4E24\u6B21\u4E3B\u53E3\u4EE4\u4E0D\u4E00\u81F4\u3002");
        await send("setup", { password: entered });
        state = await send("status");
      } else await send("unlock", { password: entered });
      await opened();
    });
  });
  $("device-unlock").addEventListener(
    "click",
    () => run(async () => {
      const secret = await deviceSecret(state.device).catch((e) => {
        throw new Error(e?.name === "NotAllowedError" ? "\u8BBE\u5907\u9A8C\u8BC1\u5DF2\u53D6\u6D88\uFF0C\u53EF\u6539\u7528\u4E3B\u53E3\u4EE4\u3002" : e.message);
      });
      await send("device-unlock", { credentialId: state.device.credentialId, secret });
      await opened();
    })
  );
  $("lock").addEventListener(
    "click",
    () => run(async () => {
      await send("lock");
      forgetView();
      location.reload();
    })
  );
  $("search").addEventListener("input", render);
  $("select-all").addEventListener("change", () => {
    for (const r of visibleRecords())
      $("select-all").checked ? selected.add(identity(r)) : selected.delete(identity(r));
    render();
  });
  $("remove").addEventListener("click", () => {
    if (!selected.size) feedback("error", "\u8BF7\u5148\u9009\u62E9\u901A\u884C\u5BC6\u94A5\u3002");
    else $("delete-dialog").showModal();
  });
  $("delete-cancel").addEventListener("click", () => $("delete-dialog").close());
  $("delete-confirm").addEventListener(
    "click",
    () => run(async () => {
      await send("remove", { ids: [...selected] });
      selected.clear();
      $("delete-dialog").close();
      await refresh();
      feedback("notice", "\u5DF2\u5220\u9664\u672C\u5730\u526F\u672C\u3002\u7F51\u7AD9\u4E0A\u7684\u51ED\u636E\u9700\u53E6\u884C\u64A4\u9500\u3002");
      await finishCompanion();
    })
  );
  $("export-format").addEventListener("change", () => {
    const plain = $("export-format").value === "bitwarden";
    $("export-encrypted").hidden = plain;
    $("export-plaintext").hidden = !plain;
    $("format-note").hidden = !plain;
    $("confirm-plaintext").checked = false;
  });
  $("export-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      if ($("export-format").value !== "bitwarden" && $("export-password").value !== $("export-confirmation").value)
        throw new Error("\u4E24\u6B21\u5907\u4EFD\u53E3\u4EE4\u4E0D\u4E00\u81F4\u3002");
      const result = await send("export", {
        password: $("export-master").value,
        ids: [...selected],
        format: $("export-format").value,
        backupPassword: $("export-password").value,
        confirmPlaintext: $("confirm-plaintext").checked
      });
      const url = URL.createObjectURL(new Blob([result.text], { type: "application/json" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
      for (const id of ["export-password", "export-confirmation", "export-master"]) $(id).value = "";
      $("confirm-plaintext").checked = false;
      feedback("notice", "\u5DF2\u751F\u6210\u5BFC\u51FA\u6587\u4EF6\u3002\u8BF7\u5728\u76EE\u6807\u8BBE\u5907\u6216\u7BA1\u7406\u5668\u4E2D\u5BFC\u5165\u5E76\u9A8C\u8BC1\u767B\u5F55\u3002");
      await finishCompanion();
    });
  });
  function clearImport() {
    importedText = "";
    importPassword = "";
    $("import-preview").hidden = true;
    $("import-list").replaceChildren();
  }
  $("import-file").addEventListener("change", clearImport);
  $("import-password").addEventListener("input", clearImport);
  $("import-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      clearImport();
      const file = $("import-file").files[0];
      if (!file || file.size > 8e6) throw new Error("\u8BF7\u9009\u62E9\u5C0F\u4E8E 8MB \u7684\u5907\u4EFD\u6587\u4EF6\u3002");
      const text = await file.text(), p = $("import-password").value;
      const result = await send("inspect", { text, backupPassword: p });
      importedText = text;
      importPassword = p;
      $("import-summary").textContent = `${result.source}\uFF1A\u65B0\u589E ${result.added} \u6761\uFF0C\u91CD\u590D ${result.duplicates} \u6761\uFF0C\u4E0D\u652F\u6301 ${result.skipped} \u6761\u3002`;
      for (const r of result.records) {
        const li = document.createElement("li");
        li.textContent = `${r.label || r.rpId} \xB7 ${r.userName}`;
        $("import-list").append(li);
      }
      $("import-preview").hidden = false;
    });
  });
  $("import-confirm").addEventListener(
    "click",
    () => run(async () => {
      const result = await send("import", { text: importedText, backupPassword: importPassword });
      clearImport();
      $("import-password").value = "";
      $("import-file").value = "";
      await refresh();
      feedback("notice", `\u5DF2\u5BFC\u5165 ${result.added} \u6761\uFF0C\u4FDD\u7559\u91CD\u590D\u8BB0\u5F55 ${result.duplicates} \u6761\u3002`);
      await finishCompanion();
    })
  );
  $("change-password-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      if ($("next-password").value !== $("next-confirmation").value)
        throw new Error("\u4E24\u6B21\u4E3B\u53E3\u4EE4\u4E0D\u4E00\u81F4\u3002");
      await send("password", {
        password: $("current-password").value,
        nextPassword: $("next-password").value
      });
      for (const id of ["current-password", "next-password", "next-confirmation"]) $(id).value = "";
      feedback("notice", "\u4E3B\u53E3\u4EE4\u5DF2\u66F4\u65B0\u3002\u8BBE\u5907\u89E3\u9501\u4ECD\u7136\u6709\u6548\uFF1B\u5DF2\u6709\u5907\u4EFD\u4ECD\u4F7F\u7528\u5BFC\u51FA\u65F6\u7684\u5907\u4EFD\u53E3\u4EE4\u3002");
    });
  });
  $("device-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      if (state.device) {
        await send("device-disable");
        feedback("notice", "\u5DF2\u505C\u7528\u8BBE\u5907\u89E3\u9501\u3002\u4E4B\u540E\u8BF7\u7528\u4E3B\u53E3\u4EE4\u89E3\u9501\u3002");
      } else {
        const password = $("device-password").value;
        if (!password) throw new Error("\u8BF7\u8F93\u5165\u4E3B\u53E3\u4EE4\u786E\u8BA4\u6B64\u64CD\u4F5C\u3002");
        await send("unlock", { password });
        const device = await enrollDevice().catch((e) => {
          throw new Error(e?.name === "NotAllowedError" ? "\u8BBE\u5907\u9A8C\u8BC1\u5DF2\u53D6\u6D88\u3002" : e.message);
        });
        await send("device-enable", { password, ...device });
        $("device-password").value = "";
        feedback("notice", "\u5DF2\u542F\u7528\u8BBE\u5907\u89E3\u9501\u3002\u4E0B\u6B21\u53EF\u76F4\u63A5\u7528 Touch ID / Windows Hello \u89E3\u9501\u3002");
      }
      state = await send("status");
      showSettings();
    });
  });
  $("lock-after").addEventListener(
    "change",
    () => run(async () => {
      state.settings = (await send("settings", { lockAfter: Number($("lock-after").value) })).settings;
      feedback("notice", "\u5DF2\u66F4\u65B0\u81EA\u52A8\u9501\u5B9A\u65F6\u95F4\u3002");
    })
  );
  $("prompt-mode").addEventListener(
    "change",
    () => run(async () => {
      state.settings = (await send("settings", { prompt: $("prompt-mode").value })).settings;
      feedback("notice", "\u5DF2\u66F4\u65B0\u786E\u8BA4\u6846\u4F4D\u7F6E\u3002");
    })
  );
  $("paused").addEventListener(
    "change",
    () => run(async () => {
      await send("pause", { paused: $("paused").checked });
      feedback("notice", $("paused").checked ? "\u5DF2\u6682\u505C\u5904\u7406\u7F51\u7AD9\u8BF7\u6C42\u3002" : "\u5DF2\u6062\u590D\u5904\u7406\u7F51\u7AD9\u8BF7\u6C42\u3002");
    })
  );
  window.addEventListener(
    "focus",
    () => run(async () => {
      if (!state?.exists || $("manager").hidden) return;
      const now = await send("status");
      if (!now.unlocked) {
        state = now;
        forgetView();
        render();
        showGate();
      }
    })
  );
  window.addEventListener("pagehide", forgetView);
  run(start);
})();
