(() => {
  // src/ui.js
  var $ = (id) => document.getElementById(id);
  var token = new URLSearchParams(location.search).get("request");
  var state;
  var password = "";
  var records = [];
  var importedText = "";
  var importPassword = "";
  var selected = /* @__PURE__ */ new Set();
  var busy = false;
  async function send(action, values = {}) {
    const result = await chrome.runtime.sendMessage({ action, token, password, ...values });
    if (!result.ok) throw new Error(result.error);
    return result;
  }
  function feedback(id, text = "") {
    $(id).textContent = text;
    $(id).hidden = !text;
  }
  async function run(action) {
    if (busy) return;
    busy = true;
    feedback("error");
    feedback("notice");
    const buttons = [...document.querySelectorAll("button")];
    buttons.forEach((b) => b.disabled = true);
    try {
      await action();
    } catch (e) {
      feedback("error", e.message || "\u65E0\u6CD5\u5B8C\u6210\u64CD\u4F5C\u3002");
    } finally {
      busy = false;
      buttons.forEach((b) => b.disabled = false);
    }
  }
  function identity(r) {
    return `${r.rpId}:${r.credentialId}`;
  }
  function visibleRecords() {
    const query = $("search").value.toLowerCase();
    return records.filter(
      (r) => `${r.rpId} ${r.userName} ${r.userDisplayName}`.toLowerCase().includes(query)
    );
  }
  function selection() {
    $("selected-count").textContent = `\u5DF2\u9009 ${selected.size} \u6761`;
    const visible = visibleRecords();
    $("select-all").checked = !!visible.length && visible.every((r) => selected.has(identity(r)));
    $("select-all").indeterminate = visible.some((r) => selected.has(identity(r))) && !$("select-all").checked;
  }
  function render() {
    $("records").replaceChildren();
    const visible = visibleRecords();
    $("count").textContent = `${records.length} \u6761\u901A\u884C\u5BC6\u94A5`;
    $("empty").hidden = records.length > 0;
    for (const r of visible) {
      const row = document.createElement("label");
      row.className = "record";
      const box = document.createElement("input");
      box.type = "checkbox";
      box.checked = selected.has(identity(r));
      box.setAttribute("aria-label", `\u9009\u62E9 ${r.rpId} ${r.userName}`);
      box.addEventListener("change", () => {
        box.checked ? selected.add(identity(r)) : selected.delete(identity(r));
        selection();
      });
      const info = document.createElement("div");
      info.className = "record-info";
      const site = document.createElement("strong");
      site.textContent = r.rpId;
      const user = document.createElement("span");
      user.textContent = r.userName || r.userDisplayName || "\u672A\u547D\u540D\u8D26\u53F7";
      info.append(site, user);
      const time = document.createElement("time");
      time.textContent = r.lastUsedAt ? `\u6700\u8FD1\u4F7F\u7528 ${new Date(r.lastUsedAt).toLocaleDateString()}` : "\u5C1A\u672A\u4F7F\u7528";
      row.append(box, info, time);
      $("records").append(row);
    }
    if (!visible.length && records.length) {
      const p = document.createElement("p");
      p.textContent = "\u6CA1\u6709\u5339\u914D\u7684\u7F51\u7AD9\u6216\u8D26\u53F7\u3002";
      $("records").append(p);
    }
    selection();
  }
  async function refresh() {
    records = (await send("list")).records;
    selected = new Set([...selected].filter((id) => records.some((r) => identity(r) === id)));
    render();
  }
  function lock() {
    password = "";
    importedText = "";
    importPassword = "";
    records = [];
    selected.clear();
    location.reload();
  }
  async function start() {
    state = await send("status");
    if (!state.exists) {
      $("gate-title").textContent = "\u521B\u5EFA\u672C\u5730\u5BC6\u94A5\u5E93";
      $("unlock").textContent = "\u521B\u5EFA\u5BC6\u94A5\u5E93";
      $("confirmation-field").hidden = false;
      $("setup-hint").hidden = false;
      $("password").minLength = 12;
      $("password").autocomplete = "new-password";
      $("confirmation").required = true;
    }
    $("paused").checked = state.paused;
    if (token) {
      $("title").textContent = state.request.kind === "create" ? "\u4FDD\u5B58\u65B0\u7684\u901A\u884C\u5BC6\u94A5" : "\u4F7F\u7528\u901A\u884C\u5BC6\u94A5\u767B\u5F55";
      $("subtitle").textContent = "\u8BF7\u6838\u5BF9\u6765\u6E90\u7F51\u7AD9\uFF0C\u518D\u89E3\u9501\u5E76\u786E\u8BA4\u3002";
      $("request-info").hidden = false;
      $("request-actions").hidden = false;
      $("origin").textContent = state.request.origin;
      $("request-account").textContent = state.request.userName ? `\u8D26\u53F7\uFF1A${state.request.userName}` : `\u51ED\u636E\u57DF\u540D\uFF1A${state.request.rpId}`;
    }
  }
  $("unlock-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      const entered = $("password").value;
      if (!state.exists && entered !== $("confirmation").value) throw new Error("\u4E24\u6B21\u4E3B\u53E3\u4EE4\u4E0D\u4E00\u81F4\u3002");
      if (!state.exists) {
        await send("setup", { password: entered });
        state.exists = true;
      }
      const result = await send("list", { password: entered });
      password = entered;
      $("password").value = "";
      $("confirmation").value = "";
      $("gate").hidden = true;
      if (token) {
        $("approval").hidden = false;
        const create = state.request.kind === "create";
        $("approval-title").textContent = create ? "\u786E\u8BA4\u4FDD\u5B58" : "\u9009\u62E9\u767B\u5F55\u8D26\u53F7";
        $("approve").textContent = create ? "\u521B\u5EFA\u5E76\u4FDD\u5B58\u901A\u884C\u5BC6\u94A5" : "\u786E\u8BA4\u767B\u5F55";
        $("choices").replaceChildren();
        if (create) {
          const p = document.createElement("p");
          p.textContent = `${state.request.rpId} \xB7 ${state.request.userName}`;
          $("choices").append(p);
        } else
          for (const [index, r] of result.records.entries()) {
            const label = document.createElement("label");
            label.className = "choice check";
            const input = document.createElement("input");
            input.type = "radio";
            input.name = "credential";
            input.value = r.credentialId;
            input.checked = index === 0;
            const text = document.createElement("span");
            text.textContent = r.userName || r.userDisplayName;
            label.append(input, text);
            $("choices").append(label);
          }
        if (!create && !result.records.length) {
          feedback("notice", "\u6CA1\u6709\u5339\u914D\u7684\u901A\u884C\u5BC6\u94A5\uFF0C\u8BF7\u4F7F\u7528\u7CFB\u7EDF\u6216\u5176\u4ED6\u9A8C\u8BC1\u5668\u3002");
          $("approve").hidden = true;
        }
        $("approve").focus();
      } else {
        $("manager").hidden = false;
        records = result.records;
        render();
        $("search").focus();
      }
    });
  });
  $("approve-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      const result = await send("approve", {
        credentialId: document.querySelector("input[name=credential]:checked")?.value
      });
      password = "";
      $("approval").hidden = true;
      $("request-actions").hidden = true;
      feedback(
        "notice",
        result.kind === "create" ? "\u5DF2\u4FDD\u5B58\u3002\u8BF7\u8FD4\u56DE\u7F51\u7AD9\u5B8C\u6210\u6CE8\u518C\u786E\u8BA4\u3002" : "\u5DF2\u5B8C\u6210\u9A8C\u8BC1\uFF0C\u8BF7\u8FD4\u56DE\u7F51\u7AD9\u3002"
      );
      setTimeout(() => window.close(), 1e3);
    });
  });
  for (const action of ["fallback", "deny"])
    $(action).addEventListener(
      "click",
      () => run(async () => {
        await send(action);
        password = "";
        window.close();
      })
    );
  $("lock").addEventListener("click", lock);
  $("search").addEventListener("input", render);
  $("select-all").addEventListener("change", () => {
    for (const r of visibleRecords())
      $("select-all").checked ? selected.add(identity(r)) : selected.delete(identity(r));
    render();
  });
  $("remove").addEventListener("click", () => {
    if (!selected.size) feedback("error", "\u8BF7\u5148\u9009\u62E9\u901A\u884C\u5BC6\u94A5\u3002");
    else $("delete-dialog").showModal();
  });
  $("delete-cancel").addEventListener("click", () => $("delete-dialog").close());
  $("delete-confirm").addEventListener(
    "click",
    () => run(async () => {
      await send("remove", { ids: [...selected] });
      selected.clear();
      $("delete-dialog").close();
      await refresh();
      feedback("notice", "\u5DF2\u5220\u9664\u672C\u5730\u526F\u672C\u3002\u7F51\u7AD9\u4E0A\u7684\u51ED\u636E\u9700\u53E6\u884C\u64A4\u9500\u3002");
    })
  );
  $("export-format").addEventListener("change", () => {
    const plain = $("export-format").value === "bitwarden";
    $("export-encrypted").hidden = plain;
    $("export-plaintext").hidden = !plain;
    $("format-note").hidden = !plain;
    $("confirm-plaintext").checked = false;
  });
  $("export-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      if ($("export-format").value !== "bitwarden" && $("export-password").value !== $("export-confirmation").value)
        throw new Error("\u4E24\u6B21\u5907\u4EFD\u53E3\u4EE4\u4E0D\u4E00\u81F4\u3002");
      const result = await send("export", {
        ids: [...selected],
        format: $("export-format").value,
        backupPassword: $("export-password").value,
        confirmPlaintext: $("confirm-plaintext").checked
      });
      const url = URL.createObjectURL(new Blob([result.text], { type: "application/json" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = result.filename;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
      $("export-password").value = "";
      $("export-confirmation").value = "";
      $("confirm-plaintext").checked = false;
      feedback("notice", "\u5DF2\u751F\u6210\u5BFC\u51FA\u6587\u4EF6\u3002\u8BF7\u5728\u76EE\u6807\u8BBE\u5907\u6216\u7BA1\u7406\u5668\u4E2D\u5BFC\u5165\u5E76\u9A8C\u8BC1\u767B\u5F55\u3002");
    });
  });
  function clearImport() {
    importedText = "";
    importPassword = "";
    $("import-preview").hidden = true;
    $("import-list").replaceChildren();
  }
  $("import-file").addEventListener("change", clearImport);
  $("import-password").addEventListener("input", clearImport);
  $("import-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      clearImport();
      const file = $("import-file").files[0];
      if (!file || file.size > 8e6) throw new Error("\u8BF7\u9009\u62E9\u5C0F\u4E8E 8MB \u7684\u5907\u4EFD\u6587\u4EF6\u3002");
      const text = await file.text(), p = $("import-password").value;
      const result = await send("inspect", { text, backupPassword: p });
      importedText = text;
      importPassword = p;
      $("import-summary").textContent = `${result.source}\uFF1A\u65B0\u589E ${result.added} \u6761\uFF0C\u91CD\u590D ${result.duplicates} \u6761\uFF0C\u4E0D\u652F\u6301 ${result.skipped} \u6761\u3002`;
      for (const r of result.records) {
        const li = document.createElement("li");
        li.textContent = `${r.rpId} \xB7 ${r.userName}`;
        $("import-list").append(li);
      }
      $("import-preview").hidden = false;
    });
  });
  $("import-confirm").addEventListener(
    "click",
    () => run(async () => {
      const result = await send("import", { text: importedText, backupPassword: importPassword });
      clearImport();
      $("import-password").value = "";
      $("import-file").value = "";
      await refresh();
      feedback("notice", `\u5DF2\u5BFC\u5165 ${result.added} \u6761\uFF0C\u4FDD\u7559\u91CD\u590D\u8BB0\u5F55 ${result.duplicates} \u6761\u3002`);
    })
  );
  $("change-password-form").addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      if ($("next-password").value !== $("next-confirmation").value)
        throw new Error("\u4E24\u6B21\u4E3B\u53E3\u4EE4\u4E0D\u4E00\u81F4\u3002");
      const nextPassword = $("next-password").value;
      await send("password", { nextPassword });
      password = nextPassword;
      $("next-password").value = "";
      $("next-confirmation").value = "";
      feedback("notice", "\u4E3B\u53E3\u4EE4\u5DF2\u66F4\u65B0\u3002\u5DF2\u6709\u5907\u4EFD\u4ECD\u4F7F\u7528\u5BFC\u51FA\u65F6\u7684\u5907\u4EFD\u53E3\u4EE4\u3002");
    });
  });
  $("paused").addEventListener(
    "change",
    () => run(async () => {
      await send("pause", { paused: $("paused").checked });
      feedback("notice", $("paused").checked ? "\u5DF2\u6682\u505C\u5904\u7406\u7F51\u7AD9\u8BF7\u6C42\u3002" : "\u5DF2\u6062\u590D\u5904\u7406\u7F51\u7AD9\u8BF7\u6C42\u3002");
    })
  );
  var lastActive = Date.now();
  for (const event of ["pointerdown", "keydown"])
    window.addEventListener(event, () => lastActive = Date.now());
  setInterval(() => {
    if (password && Date.now() - lastActive > 5 * 6e4) lock();
  }, 1e3);
  window.addEventListener("pagehide", () => {
    password = "";
    importedText = "";
    importPassword = "";
    records = [];
  });
  run(start);
})();
